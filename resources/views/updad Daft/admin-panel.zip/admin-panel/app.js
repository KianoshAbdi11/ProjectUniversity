const navToggleIcon = document.querySelector(".box-header-menu");
const menu = document.querySelector(".menu");
const menuDrop = document.querySelector(".menu-item-drop")


navToggleIcon.addEventListener("click",clickNavToggle)
function clickNavToggle(){
    this.classList.toggle("box-header-menu-open")
    menu.classList.toggle("menu--open")
}
menuDrop.addEventListener("click",function(){
    men
})